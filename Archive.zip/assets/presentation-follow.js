(() => {
  "use strict";

  const basePath = document.querySelector('meta[name="app-base-path"]')?.content || "";
  const token = new URLSearchParams(window.location.search).get("token") || "";
  const status = document.querySelector("[data-follow-status]");
  const stage = document.querySelector("[data-follow-stage]");
  const title = document.querySelector("[data-follow-title]");
  const count = document.querySelector("[data-follow-count]");
  const themes = new Set(["modern", "editorial", "vibrant", "data", "minimal"]);
  let timer = null;
  let lastSlideKey = "";
  let stopped = false;

  const textElement = (tag, text, className = "") => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    element.textContent = text;
    return element;
  };

  function showEnded(message) {
    stopped = true;
    if (timer !== null) window.clearTimeout(timer);
    status.textContent = message;
    stage.replaceChildren(textElement("p", message, "presentation-follow-placeholder"));
    count.textContent = "";
  }

  function renderSlide(data) {
    title.textContent = data.title || "Live classroom presentation";
    count.textContent = `Slide ${data.active_slide + 1} of ${data.slide_count}`;
    status.textContent = data.subject
      ? `Following your teacher · ${data.subject}${data.year ? ` · ${data.year}` : ""}`
      : "Following your teacher's presentation";
    const theme = themes.has(data.visual_theme) ? data.visual_theme : "modern";
    const template = ["lesson", "inquiry", "worked", "discussion", "project", "revision", "flipped"].includes(data.template)
      ? data.template
      : "lesson";
    const slide = data.slide || {};
    const article = document.createElement("article");
    article.className = `presentation-slide-preview presentation-theme-${theme} presentation-template-${template}`;
    article.append(textElement("h1", String(slide.title || "Presentation slide")));
    const points = Array.isArray(slide.key_points) ? slide.key_points.filter((point) => typeof point === "string" && point.trim()).slice(0, 12) : [];
    if (points.length) {
      const list = document.createElement("ul");
      points.forEach((point) => list.append(textElement("li", point)));
      article.append(list);
    }
    if (slide.visual_suggestion) {
      const visual = document.createElement("div");
      visual.className = "presentation-visual";
      visual.append(textElement("strong", "Visual"));
      visual.append(textElement("p", String(slide.visual_suggestion)));
      article.append(visual);
    }
    if (slide.activity) article.append(textElement("p", String(slide.activity)));
    stage.replaceChildren(article);
  }

  async function poll() {
    if (stopped || document.hidden) return;
    try {
      const response = await fetch(`${basePath}/api/presentation-simulations/${encodeURIComponent(token)}`, {
        credentials: "same-origin",
        headers: { Accept: "application/json" },
        cache: "no-store"
      });
      const data = await response.json();
      if (!response.ok) {
        if (response.status === 404) {
          showEnded(data.error || "This presentation link is invalid or no longer available.");
          return;
        }
        throw new Error(data.error || `The presentation could not be refreshed (HTTP ${response.status}).`);
      }
      if (data.status !== "active") {
        showEnded("The teacher has ended this presentation.");
        return;
      }
      const slideKey = `${data.active_slide}:${data.slide_count}:${data.title}`;
      if (slideKey !== lastSlideKey) {
        renderSlide(data);
        lastSlideKey = slideKey;
      } else {
        title.textContent = data.title || "Live classroom presentation";
      }
    } catch (error) {
      status.textContent = error instanceof Error ? `Reconnecting… ${error.message}` : "Reconnecting to the live presentation…";
    }
    if (!stopped) timer = window.setTimeout(poll, 1800);
  }

  if (!/^[a-fA-F0-9]{64}$/.test(token)) {
    showEnded("This presentation link is missing a valid sharing token.");
    return;
  }
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && !stopped) {
      if (timer !== null) window.clearTimeout(timer);
      void poll();
    }
  });
  void poll();
})();
