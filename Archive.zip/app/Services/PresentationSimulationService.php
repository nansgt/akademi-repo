<?php
declare(strict_types=1);

namespace Akademi\Services;

use Akademi\Database\Connection;
use PDO;
use RuntimeException;

final class PresentationSimulationService
{
    private const THEMES = ['modern', 'editorial', 'vibrant', 'data', 'minimal'];
    private const TEMPLATES = ['lesson', 'inquiry', 'worked', 'discussion', 'project', 'revision', 'flipped'];
    private const MAX_SLIDES = 100;
    private const MAX_PRESENTATION_BYTES = 500000;

    public function create(int $userId, array $input): array
    {
        $title = trim((string)($input['title'] ?? ''));
        $presentation = $input['presentation'] ?? null;
        if ($title === '' || mb_strlen($title) > 255 || !is_array($presentation)) {
            throw new RuntimeException('The presentation details are invalid.', 422);
        }
        $slides = $presentation['slides'] ?? null;
        if (!is_array($slides) || count($slides) < 1 || count($slides) > self::MAX_SLIDES) {
            throw new RuntimeException('A live presentation must contain between 1 and 100 slides.', 422);
        }
        $theme = (string)($presentation['visual_theme'] ?? 'modern');
        $template = (string)($presentation['template'] ?? 'lesson');
        if (!in_array($theme, self::THEMES, true) || !in_array($template, self::TEMPLATES, true)) {
            throw new RuntimeException('The presentation design or teaching structure is invalid.', 422);
        }
        foreach ($slides as $slide) {
            if (!is_array($slide) || !is_string($slide['title'] ?? null)) {
                throw new RuntimeException('One or more presentation slides are invalid.', 422);
            }
        }
        $encodedPresentation = json_encode([
            'subject' => mb_substr(trim((string)($presentation['subject'] ?? '')), 0, 190, 'UTF-8'),
            'year' => mb_substr(trim((string)($presentation['year'] ?? '')), 0, 40, 'UTF-8'),
            'template' => $template,
            'visual_theme' => $theme,
            'slides' => array_values($slides),
        ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        if (strlen($encodedPresentation) > self::MAX_PRESENTATION_BYTES) {
            throw new RuntimeException('This presentation is too large to share live. Reduce the slide content and try again.', 413);
        }
        $token = bin2hex(random_bytes(32));
        $statement = Connection::get()->prepare(
            'INSERT INTO presentation_simulations
             (user_id, share_token_hash, title, presentation_data, expires_at)
             VALUES (:user_id, :token_hash, :title, :presentation_data, DATE_ADD(UTC_TIMESTAMP(), INTERVAL 12 HOUR))'
        );
        $statement->execute([
            'user_id' => $userId,
            'token_hash' => hash('sha256', $token, true),
            'title' => $title,
            'presentation_data' => $encodedPresentation,
        ]);
        $id = (int)Connection::get()->lastInsertId();
        return [
            'id' => $id,
            'url' => app_url('presentation/follow?token=' . rawurlencode($token)),
            'expires_at' => gmdate('c', time() + 12 * 60 * 60),
        ];
    }

    public function update(int $userId, int $simulationId, array $input): array
    {
        $status = (string)($input['status'] ?? 'active');
        $activeSlide = filter_var($input['active_slide'] ?? null, FILTER_VALIDATE_INT);
        if (!in_array($status, ['active', 'ended'], true) || $activeSlide === false || $activeSlide < 0) {
            throw new RuntimeException('The live presentation update is invalid.', 422);
        }
        $pdo = Connection::get();
        $select = $pdo->prepare(
            'SELECT presentation_data, status FROM presentation_simulations
             WHERE id = :id AND user_id = :user_id AND expires_at > UTC_TIMESTAMP() LIMIT 1'
        );
        $select->execute(['id' => $simulationId, 'user_id' => $userId]);
        $row = $select->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException('The live presentation is no longer available.', 404);
        }
        if ($row['status'] !== 'active') {
            throw new RuntimeException('This live presentation has already ended.', 409);
        }
        $presentation = json_decode((string)$row['presentation_data'], true, 32, JSON_THROW_ON_ERROR);
        $slideCount = count($presentation['slides'] ?? []);
        if ($activeSlide >= $slideCount) {
            throw new RuntimeException('Choose a slide within this presentation.', 422);
        }
        $update = $pdo->prepare(
            'UPDATE presentation_simulations SET active_slide = :active_slide, status = :status
             WHERE id = :id AND user_id = :user_id AND status = \'active\' AND expires_at > UTC_TIMESTAMP()'
        );
        $update->execute([
            'active_slide' => $activeSlide,
            'status' => $status,
            'id' => $simulationId,
            'user_id' => $userId,
        ]);
        if ($update->rowCount() === 0) {
            throw new RuntimeException('The live presentation changed before this update was saved. Refresh and try again.', 409);
        }
        return ['active_slide' => $activeSlide, 'status' => $status];
    }

    public function read(string $token): array
    {
        $statement = Connection::get()->prepare(
            'SELECT title, presentation_data, active_slide, status, expires_at
             FROM presentation_simulations WHERE share_token_hash = :token_hash LIMIT 1'
        );
        $statement->execute(['token_hash' => hash('sha256', $token, true)]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            throw new RuntimeException('This presentation link is invalid or no longer available.', 404);
        }
        $presentation = json_decode((string)$row['presentation_data'], true, 32, JSON_THROW_ON_ERROR);
        $slides = $presentation['slides'] ?? [];
        $activeSlide = (int)$row['active_slide'];
        $ended = $row['status'] !== 'active' || strtotime((string)$row['expires_at'] . ' UTC') <= time();
        return [
            'title' => (string)$row['title'],
            'subject' => (string)($presentation['subject'] ?? ''),
            'year' => (string)($presentation['year'] ?? ''),
            'template' => (string)($presentation['template'] ?? 'lesson'),
            'visual_theme' => (string)($presentation['visual_theme'] ?? 'modern'),
            'active_slide' => $activeSlide,
            'slide_count' => count($slides),
            'slide' => $ended ? null : ($slides[$activeSlide] ?? null),
            'status' => $ended ? 'ended' : 'active',
            'expires_at' => gmdate('c', strtotime((string)$row['expires_at'] . ' UTC')),
        ];
    }
}
