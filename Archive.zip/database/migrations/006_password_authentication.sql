ALTER TABLE users
    ADD COLUMN password_hash VARCHAR(255) NULL AFTER email_verified_at;
